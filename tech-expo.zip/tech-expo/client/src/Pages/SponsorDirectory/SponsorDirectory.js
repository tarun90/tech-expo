import React from 'react'

const SponsorDirectory = () => {
  return (
    <div>SponsorDirectory</div>
  )
}

export default SponsorDirectory