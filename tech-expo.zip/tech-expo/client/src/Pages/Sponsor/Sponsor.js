import React from 'react'

const Sponsor = () => {
  return (
    <div>Sponsor</div>
  )
}

export default Sponsor