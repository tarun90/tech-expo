import React from 'react'

const FloorPlan = () => {
  return (
    <div>FloorPlan</div>
  )
}

export default FloorPlan