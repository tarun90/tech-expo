import React from 'react'

const Media = () => {
  return (
    <div>Media</div>
  )
}

export default Media