import React from 'react'

const AboutEvent = () => {
  return (
    <div>AboutEvent</div>
  )
}

export default AboutEvent