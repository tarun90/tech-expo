import React from 'react'

const BecomeExhibitor = () => {
  return (
    <div>BecomeExhibitor</div>
  )
}

export default BecomeExhibitor