import React from 'react'

const Exhibitor = () => {
  return (
    <div>Exhibitor</div>
  )
}

export default Exhibitor