import React from 'react'

const Speaker = () => {
  return (
    <div>Speaker</div>
  )
}

export default Speaker