import React from 'react'

const RefundPolicy = () => {
  return (
    <div>RefundPolicy</div>
  )
}

export default RefundPolicy