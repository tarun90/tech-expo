import React from 'react'

const CoreTeam = () => {
  return (
    <div>CoreTeam</div>
  )
}

export default CoreTeam