import logo from './logo.svg';
import './App.css';
import RoutesComponent from './Routes';

function App() {
  return (
    <div className="App">
      <RoutesComponent/>
    </div>
  );
}

export default App;
